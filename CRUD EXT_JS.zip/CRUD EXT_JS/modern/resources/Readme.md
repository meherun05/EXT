# modern/resources

This folder contains resources (such as images) needed by the modern build profile. 

This file can be removed.
